import java.lang.*;//java.lang contains classes that are fundamental to the design of the Java programming language.
import javax.swing.*;
import javax.swing.border.*; //for border 
import java.awt.*; 
import java.awt.event.*; //event perform or action 
import java.sql.*; //sql database connection

public class  Login extends JFrame implements ActionListener  //login class inherit jframe class and implements interface Action
{
	public JPanel panel;  // for panel design
	public JLabel userlabel,passlabel,logolabel;  //label design
	public JTextField userfield;  // for textfield
	public JPasswordField passfield;  //for passwordfield
	public JButton login,forgetPassword;  //for button
	public ImageIcon logo;   //for imageicon adding
	
	
	public Login()
	{
		super("Login Form");  //adding window name
		this.setSize(800,600);//boundary of frame
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // an option for the close button which exit the application 
		
		Font myFont= new Font("Consolas",Font.PLAIN, 25);  //font selection (PLAIN)
		Color fontColor = new Color (41,41,41);//font color setting in RGB method 
		Color panelColor = new Color (225,225,225); //coloring panel in RGB method
		Color buttonColColor = new Color (74,96,132); //button coloring
		
		panel= new JPanel (); 
		panel.setLayout(null); 
		panel.setBackground(panelColor); //panel backgroung operation
		
		
		logo = new ImageIcon("logo.jpg"); 
		logolabel = new JLabel(logo);
		logolabel.setBounds(0,-25,800,150);  //bound the location of this label
		panel.add(logolabel);
		
		int labelxAxis=200,labelyAxis=200,labelWidth=200,labelHeight=40; //initially declearing value of label and textfield bound
		int fieldxAxis=400,fieldyAxis=205,fieldWidth=200,fieldHeight=30;
		
		
		userlabel=new JLabel("Bank ID:");
		userlabel.setBounds(labelxAxis,labelyAxis,labelWidth,labelHeight);
		userlabel.setFont(myFont);
		userlabel.setForeground(fontColor); //set for ground colour as font 
		panel.add(userlabel);
		
		userfield=new JTextField();
		userfield.setBounds(fieldxAxis,fieldyAxis,fieldWidth,fieldHeight);
		userfield.setFont(myFont);
		panel.add(userfield);
		
		passlabel=new JLabel("Password:");  //creating new object for passsword label
		passlabel.setBounds(labelxAxis,labelyAxis+100,labelWidth,labelHeight);
		passlabel.setFont(myFont);
		passlabel.setForeground(fontColor);
		panel.add(passlabel);
		
		passfield=new JPasswordField();
		passfield.setBounds(fieldxAxis,fieldyAxis+100,fieldWidth,fieldHeight);
		passfield.setFont(myFont);
		panel.add(passfield);
		
		
		login=new JButton("Login");
		login.setBounds(labelxAxis+100,labelyAxis+200,labelWidth-80,labelHeight);
		login.setFont(myFont);
		login.setForeground(fontColor);
		login.setBackground(buttonColColor);
		login.addActionListener(this);
		panel.add(login);
		
		forgetPassword=new JButton("Forget Password");
		forgetPassword.setBounds(labelxAxis+300,labelyAxis+320,labelWidth+50,labelHeight-10);
		forgetPassword.setFont(myFont);
		forgetPassword.setForeground(fontColor);
		forgetPassword.setBackground(buttonColColor);
		forgetPassword.addActionListener(this);
		panel.add(forgetPassword);
		
		
		this.add(panel);	
	}
	public void actionPerformed(ActionEvent ae) //The actionPerformed method is called when the associated object generates a action
	{ 
		String text = ae.getActionCommand();  //getActionCommand() gives you a String representing the action command.
		if(ae.getSource()== login)  //We can use getSource() to identify the component and execute corresponding lines of code within an action-listener.
		{
			checkLogin();  // a function for login operation 
		}
		if(ae.getSource()== forgetPassword)
		{
			ForgetPassword fp=new ForgetPassword();
			fp.setVisible(true);
			this.setVisible(false);
		}
		
	}
	
	
	
	
	
	public void checkLogin()
	{
		String query = "SELECT `Bank_id`, `Password`, `Status` FROM `login`;";     
        Connection con=null;//for connection//object of Connection can be used to get the object of Statement and Database.
        Statement st = null;//for query execution //The Statement interface provides methods to execute queries with the database
		// it provides factory method to get the object of ResultSet.
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");        /*load driver//forName() method of Class class is used to register the driver class.
			                                               This method is used to dynamically load the driver class.*/
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");     //The getConnection() method of DriverManager class is used to establish connection with the database.
			System.out.println("connection done");                                                 //connection with database established 
			st = con.createStatement();                                  /*The createStatement() method of Connection interface is used to create statement.
			                                                                 creates a statement object that can be used to execute SQL queries. 
                                                                            The object of statement is responsible to execute queries with the database.*/
			System.out.println("statement created");
			rs = st.executeQuery(query);                                       /*The executeQuery() method of Statement interface is used to execute queries to the database.
			                                                                     This method returns the object of ResultSet that can be used to get all the records of a table.*/
			System.out.println("results received");
			
			boolean flag = false;			
			while(rs.next())                                                 /* next() is used to move the cursor to the one row next from the current position.*/
			{ 
                String Bank_id = rs.getString("Bank_id");                              //getting input from the bank id;
				String Password = rs.getString("Password");                        //is used to return the data of specified column index of the current row as String.
				int Status = rs.getInt("Status");                             //is used to return the data of specified column index of the current row as integer .
				
				if(Bank_id.equals(userfield.getText()) && Password.equals(passfield.getText()))           //condition checking for bankid and password checking ;
				{
					flag=true;
					if(Status==1)                  //if stauts=1 then this is a employee;
					{
						EmployeeInfo ep =new EmployeeInfo(Bank_id);
			            ep.setVisible(true);
			            this.setVisible(false);
					}
					else if(Status==0)  //status=0 means this is a customer who login into the the apps
					{
						CustomerInfo ch = new CustomerInfo(Bank_id);  //a function for getting 
						CustomerBill ch1 = new CustomerBill(Bank_id);
						CustomerTransfer ch2 = new CustomerTransfer(Bank_id);
						CustomerWithdraw ch3 = new CustomerWithdraw(Bank_id);
						ch.setVisible(true);
						this.setVisible(false);
					}
					else if(Status==2)
					{
						AdminInfo ad=new AdminInfo(Bank_id);
						ad.setVisible(true);
			            this.setVisible(false);
					}
				}
			}
			if(!flag)
			{
				JOptionPane.showMessageDialog(this,"Invalid ID or Password"); 
			}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();//closes the connection and Releases a JDBC resources immediately.
            }
            catch(Exception ex){}
        }
	}
}
